/*
 * main.cpp
 *
 * Created on: 26 Dec 2015
 *     Author: Fabian Meyer
 *    License: MIT
 */

#define CATCH_CONFIG_MAIN
#include <catch.hpp>
